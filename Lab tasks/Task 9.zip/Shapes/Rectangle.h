#pragma once
#include "Polygon.h"

class Rectangle : public Polygon {
 public:
 int Area();
};
