#pragma once
class Base {
virtual void DummyFunction();
};