#include "Derived.h"
Derived::Derived()
{
 a = 0;
}
