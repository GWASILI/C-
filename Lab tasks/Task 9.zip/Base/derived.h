#pragma once
#include "Base.h"
class Derived : public Base {
public:
Derived();
private:
int a;
};